namespace WinFormsApp13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //button1.Size = new Size(300, 100);
            //button1.Text = "����";
            //button1.BackColor = Color.Red;
            int a = button1.Location.X;
            int b = button1.Location.Y;
            button1.Location = new Point(a + 20, b+0 );
            if (a >= 800) {

                MessageBox.Show("���Դϴ�");
                button1.Location = new Point(732, 12);
            }

        }
    }
}
