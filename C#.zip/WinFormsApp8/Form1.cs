namespace WinFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void box(string buttonName)
        {
            MessageBox.Show(buttonName);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            box("��ư 1 Ŭ��");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            box("��ư 2 Ŭ��");
        }
    }
}
