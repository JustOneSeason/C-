using Microsoft.VisualBasic.Devices;

namespace WinFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                if (label1.Location.X < 0)
                {
                    MessageBox.Show(" ���� ��");
                }
                else {
                    label1.Location = new Point(label1.Location.X - 2, label1.Location.Y);
                }
            }
            else if (e.KeyCode == Keys.W) {
                if (label1.Location.Y < 0)
                {
                    MessageBox.Show(" �� ��");
                }
                else
                {
                    label1.Location = new Point(label1.Location.X, label1.Location.Y - 2);
                }
            }
            else if (e.KeyCode == Keys.D)
            {
                if (label1.Location.X == 788)
                {
                    MessageBox.Show(" ������ ��");
                }
                else
                {
                    label1.Location = new Point(label1.Location.X + 2, label1.Location.Y);
                }
            }
            else if (e.KeyCode == Keys.S)
            {
                if (label1.Location.Y == 435)
                {
                    MessageBox.Show(" �Ʒ� ��");
                }
                else
                {
                    label1.Location = new Point(label1.Location.X, label1.Location.Y + 2);
                }

            }
        }
    }
}
