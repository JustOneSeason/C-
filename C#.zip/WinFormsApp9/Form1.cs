namespace WinFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int input1 = Int32.Parse(label1.Text);
            input1 += 1;
            label1.Text = input1.ToString();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A) {
                int input1 = Int32.Parse(label1.Text);
                input1 += 1;
                label1.Text = input1.ToString();
            }
            if (e.KeyCode == Keys.S){
                int input1 = Int32.Parse(label1.Text);
                input1 -= 1;
                label1.Text = input1.ToString();
            }
        }
    }
}
