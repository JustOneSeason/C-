namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("���� �Է��ϼ���");
            }
            else
            {
                int input1 = Int32.Parse(textBox1.Text);
                int input2 = Int32.Parse(textBox2.Text);

                label1.Text = (input1 + input2).ToString();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == ""){
                MessageBox.Show("���� �Է��ϼ���");
            }
            else{
                int input1 = Int32.Parse(textBox1.Text);
                int input2 = Int32.Parse(textBox2.Text);

                label1.Text = (input1 - input2).ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == ""){
                MessageBox.Show("���� �Է��ϼ���");
            }
            else{
                int input1 = Int32.Parse(textBox1.Text);
                int input2 = Int32.Parse(textBox2.Text);

                label1.Text = (input1 * input2).ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == ""){
                MessageBox.Show("���� �Է��ϼ���");
            }
            else{
                float input1 = float.Parse(textBox1.Text);
                float input2 = float.Parse(textBox2.Text);

                label1.Text = (input1 / input2).ToString();
            }
        }
    }
}
