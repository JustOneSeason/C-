namespace WinFormsApp16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int count = 0;


        private void timer1_Tick(object sender, EventArgs e)
        {

            count += 1;

            label1.Text = count.ToString();

            if (count >= 10) {

                count = 0;
                timer1.Stop();
                MessageBox.Show("Ÿ�̸� ����");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
