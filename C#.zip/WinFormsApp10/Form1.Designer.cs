﻿namespace WinFormsApp10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_change = new Button();
            SuspendLayout();
            // 
            // btn_change
            // 
            btn_change.BackColor = SystemColors.ActiveCaption;
            btn_change.Font = new Font("맑은 고딕", 18F, FontStyle.Bold, GraphicsUnit.Point, 129);
            btn_change.Location = new Point(322, 83);
            btn_change.Name = "btn_change";
            btn_change.Size = new Size(158, 52);
            btn_change.TabIndex = 0;
            btn_change.Text = "클릭하세요";
            btn_change.UseVisualStyleBackColor = false;
            btn_change.Click += button1_Click;
            btn_change.MouseEnter += btn_change_MouseEnter;
            btn_change.MouseLeave += btn_change_MouseLeave;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(784, 461);
            Controls.Add(btn_change);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btn_change;
    }
}
