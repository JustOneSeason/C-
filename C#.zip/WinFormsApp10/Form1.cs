namespace WinFormsApp10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_change.BackColor = Color.Blue;
            btn_change.ForeColor = Color.Yellow;
            btn_change.Size = new Size(200, 100);
            btn_change.Location = new Point(0, 0);
            btn_change.Text = "C#";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "��ư�� �������";
            this.BackColor = Color.Orange;
            btn_change.Hide();
            MessageBox.Show("��ư�� ���������~");
        }

        private void btn_change_MouseEnter(object sender, EventArgs e)
        {
            btn_change.Text = "���콺 �ö��";
            btn_change.BackColor = Color.Purple;

        }

        private void btn_change_MouseLeave(object sender, EventArgs e)
        {
            btn_change.Text = "���콺 ����";
            btn_change.BackColor= Color.Green;
        }
    }
}
