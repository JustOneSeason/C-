﻿namespace TreeView
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tree_pet = new System.Windows.Forms.TreeView();
            cb_original = new CheckBox();
            pb_pet = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pb_pet).BeginInit();
            SuspendLayout();
            // 
            // tree_pet
            // 
            tree_pet.Location = new Point(80, 34);
            tree_pet.Name = "tree_pet";
            tree_pet.Size = new Size(278, 377);
            tree_pet.TabIndex = 0;
            tree_pet.AfterSelect += tree_pet_AfterSelect;
            // 
            // cb_original
            // 
            cb_original.AutoSize = true;
            cb_original.Location = new Point(531, 98);
            cb_original.Name = "cb_original";
            cb_original.Size = new Size(106, 19);
            cb_original.TabIndex = 1;
            cb_original.Text = "원본 크기 보기";
            cb_original.UseVisualStyleBackColor = true;
            cb_original.CheckedChanged += cb_original_CheckedChanged;
            // 
            // pb_pet
            // 
            pb_pet.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pb_pet.Location = new Point(475, 123);
            pb_pet.Name = "pb_pet";
            pb_pet.Size = new Size(216, 288);
            pb_pet.TabIndex = 2;
            pb_pet.TabStop = false;
            pb_pet.Click += pb_pet_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pb_pet);
            Controls.Add(cb_original);
            Controls.Add(tree_pet);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pb_pet).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TreeView tree_pet;
        private CheckBox cb_original;
        private PictureBox pb_pet;
    }
}
