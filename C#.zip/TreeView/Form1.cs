namespace TreeView
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tree_pet_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //������
            if (e.Node.Text == "������1")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/dog1.png");
            }
            else if (e.Node.Text == "������2")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/dog2.png");
            }
            else if (e.Node.Text == "������3")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/��.png");
            }
            //������
            else if (e.Node.Text == "������1")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/cat1.png");
            }
            else if (e.Node.Text == "������2")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/cat2.png");
            }
            //��
            else if (e.Node.Text == "��1")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/bird1.png");
            }
            else if (e.Node.Text == "��2")
            {
                pb_pet.Image = Bitmap.FromFile("D:/images/bird2.png");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TreeNode petRoot = new TreeNode("����");

            TreeNode dogTree = new TreeNode("������");
            dogTree.Nodes.Add("������1");
            dogTree.Nodes.Add("������2");
            dogTree.Nodes.Add("������3");
            petRoot.Nodes.Add(dogTree);

            TreeNode catTree = new TreeNode("������");
            catTree.Nodes.Add("������1");
            catTree.Nodes.Add("������2");
            petRoot.Nodes.Add(catTree);

            TreeNode birdTree = new TreeNode("��");
            birdTree.Nodes.Add("��1");
            birdTree.Nodes.Add("��2");
            petRoot.Nodes.Add(birdTree);

            tree_pet.Nodes.Add(petRoot);
            pb_pet.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void pb_pet_Click(object sender, EventArgs e)
        {

        }

        private void cb_original_CheckedChanged(object sender, EventArgs e)
        {
            if (!cb_original.Checked) {
                pb_pet.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else {
                pb_pet.SizeMode = PictureBoxSizeMode.Normal;
            }
        }
    }
}
