namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("���̵� ��й�ȣ�� �Է��ϼ���");
            }
            if (textBox1.Text == "asd" && textBox2.Text == "zxc")
            {
                MessageBox.Show("�α��� ����");
            }
            else {
                MessageBox.Show("�α��� ����");
                textBox2.Text = "";
            }
        }
    }
}
