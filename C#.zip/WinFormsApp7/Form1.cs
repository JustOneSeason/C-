namespace WinFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void add(int input1, int input2) {

            int add = input1 + input2;
            label1.Text = add.ToString();
        }
        private void minus(int input1, int input2) { 
            int minus = input1 - input2;   
            label2.Text = minus.ToString();
        }
        private void mut(int input1, int input2) { 
            int mut = input1 * input2;
            label3.Text = mut.ToString();
        }

        private void divide(int input1, int input2) { 
            int divide = input1 / input2;
            label4.Text = divide.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int input1 = Int32.Parse(textBox1.Text);
            int input2 = Int32.Parse(textBox2.Text);
            add(input1, input2);
            minus(input1, input2);
            mut(input1, input2);
            divide(input1, input2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int input1 = Int32.Parse(textBox3.Text);
            int input2 = Int32.Parse(textBox4.Text);
            add(input1, input2);
            minus(input1, input2);
            mut(input1, input2);
            divide(input1, input2);
        }
    }
}
