﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("안녕하세요?");
            //Console.WriteLine("{0}","안녕하세요?");
            //Console.WriteLine("이름={0},나이={1}","둘리",35);
            //Console.WriteLine("100");
            //Console.WriteLine("{0:D}", 100);
            //Console.WriteLine("100+100");
            //Console.WriteLine("{0:D}", 100 + 100);
            //Console.WriteLine(String.Format("{0:D}", 100 , 200));
            //Console.WriteLine(String.Format("{0:D} {1:D}", 100,200));
            //Console.WriteLine("{0:D} / {1:D} = {2:F}", 100, 200, 0.5);

            //Console.WriteLine("{0:D}", 123);
            //Console.WriteLine("{0,5:D}",123);//0~5자리 만들기
            //Console.WriteLine("{0,5:D5}", 123);//0~5자리 만들고 앞부분 0으로 채움

            //Console.WriteLine("{0:F}", 123.456);
            //Console.WriteLine("{0,8:F1}", 123.456);
            //Console.WriteLine("{0,8:f4}", 123.456);

            //Console.WriteLine("{0:S}", "CSharp");
            //Console.WriteLine("{0,8:S}", "CSharp");

            //Console.WriteLine("한 행입니다. 또 한 행입니다");
            //Console.WriteLine("한 행입니다. \n또 한 행입니다");

            //Console.WriteLine("\n줄바꿈\n연습");
            //Console.WriteLine("\t탭키\t연습");
            //Console.WriteLine("글자가\"강조\"되는 효과1");
            //Console.WriteLine("글자가\'강조\'되는 효과2");
            //Console.WriteLine("\\\\\\역슬레쉬 세 개 출력");
            //Console.WriteLine("\\n\\t\\그대로 출력");

            //Console.WriteLine("    ♣");
            //Console.WriteLine("   ♣♣♣");
            //Console.WriteLine("  ♣♣♣♣♣");
            //Console.WriteLine(" ♣♣♣♣♣♣♣");
            //Console.WriteLine("♣♣♣♣♣♣♣♣♣");
            //Console.WriteLine(" ♣♣♣♣♣♣♣");
            //Console.WriteLine("  ♣♣♣♣♣");
            //Console.WriteLine("   ♣♣♣");
            //Console.WriteLine("    ♣");

            bool boolVar = true;
            int intVar = 0;
            float floatVar = 0.0f;
            char charVar = ' ';
            string strVar = " ";

            boolVar = false;
            intVar = 100;
            floatVar = 12.345f;
            charVar = 'A';
            strVar = "안뇽?";



            //Console.WriteLine(boolVar.GetType());
            //Console.WriteLine(intVar.GetType());
            //Console.WriteLine(floatVar.GetType());
            //Console.WriteLine(charVar.GetType());
            //Console.WriteLine(strVar.GetType());



        }
    }
}
