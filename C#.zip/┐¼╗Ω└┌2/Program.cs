﻿namespace 연산자2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int v1 = 5, v2 = 3;

            num = v1 + v2;
            Console.WriteLine("{0:D} + {1:D} = {2:D}",v1 ,v2,num);
            num = v1 - v2;
            Console.WriteLine("{0:D} - {1:D} = {2:D}", v1, v2, num);
            num = v1 * v2;
            Console.WriteLine("{0:D} * {1:D} = {2:D}", v1, v2, num);
            num = v1/ v2;
            Console.WriteLine("{0:D} / {1:D} = {2:f}", v1, v2, num);
            num = v1 % v2;
            Console.WriteLine("{0:D} % {1:D} = {2:D}", v1, v2, num);

        }
    }
}
