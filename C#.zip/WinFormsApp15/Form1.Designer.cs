﻿namespace WinFormsApp15
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_run = new Button();
            gbox_car = new GroupBox();
            cb_porsche = new CheckBox();
            cb_audi = new CheckBox();
            cb_bmw = new CheckBox();
            cb_benz = new CheckBox();
            gbox_tang = new GroupBox();
            rdo_raw = new RadioButton();
            rdo_pick = new RadioButton();
            rdo_pour = new RadioButton();
            rich_result = new RichTextBox();
            gbox_car.SuspendLayout();
            gbox_tang.SuspendLayout();
            SuspendLayout();
            // 
            // btn_run
            // 
            btn_run.Location = new Point(335, 332);
            btn_run.Name = "btn_run";
            btn_run.Size = new Size(75, 57);
            btn_run.TabIndex = 0;
            btn_run.Text = "결정하기";
            btn_run.UseVisualStyleBackColor = true;
            btn_run.Click += btn_run_Click;
            // 
            // gbox_car
            // 
            gbox_car.Controls.Add(cb_porsche);
            gbox_car.Controls.Add(cb_audi);
            gbox_car.Controls.Add(cb_bmw);
            gbox_car.Controls.Add(cb_benz);
            gbox_car.Location = new Point(201, 112);
            gbox_car.Name = "gbox_car";
            gbox_car.Size = new Size(154, 199);
            gbox_car.TabIndex = 1;
            gbox_car.TabStop = false;
            gbox_car.Text = "좋아하는 자동차";
            // 
            // cb_porsche
            // 
            cb_porsche.AutoSize = true;
            cb_porsche.Location = new Point(43, 108);
            cb_porsche.Name = "cb_porsche";
            cb_porsche.Size = new Size(62, 19);
            cb_porsche.TabIndex = 3;
            cb_porsche.Text = "포르쉐";
            cb_porsche.UseVisualStyleBackColor = true;
            // 
            // cb_audi
            // 
            cb_audi.AutoSize = true;
            cb_audi.Location = new Point(43, 83);
            cb_audi.Name = "cb_audi";
            cb_audi.Size = new Size(62, 19);
            cb_audi.TabIndex = 2;
            cb_audi.Text = "아우디";
            cb_audi.UseVisualStyleBackColor = true;
            // 
            // cb_bmw
            // 
            cb_bmw.AutoSize = true;
            cb_bmw.Location = new Point(43, 58);
            cb_bmw.Name = "cb_bmw";
            cb_bmw.Size = new Size(55, 19);
            cb_bmw.TabIndex = 1;
            cb_bmw.Text = "BMW";
            cb_bmw.UseVisualStyleBackColor = true;
            // 
            // cb_benz
            // 
            cb_benz.AutoSize = true;
            cb_benz.Location = new Point(43, 33);
            cb_benz.Name = "cb_benz";
            cb_benz.Size = new Size(50, 19);
            cb_benz.TabIndex = 0;
            cb_benz.Text = "벤츠";
            cb_benz.UseVisualStyleBackColor = true;
            // 
            // gbox_tang
            // 
            gbox_tang.Controls.Add(rdo_raw);
            gbox_tang.Controls.Add(rdo_pick);
            gbox_tang.Controls.Add(rdo_pour);
            gbox_tang.Location = new Point(392, 112);
            gbox_tang.Name = "gbox_tang";
            gbox_tang.Size = new Size(167, 199);
            gbox_tang.TabIndex = 2;
            gbox_tang.TabStop = false;
            gbox_tang.Text = "탕수육 먹는 방법";
            // 
            // rdo_raw
            // 
            rdo_raw.AutoSize = true;
            rdo_raw.Location = new Point(41, 83);
            rdo_raw.Name = "rdo_raw";
            rdo_raw.Size = new Size(73, 19);
            rdo_raw.TabIndex = 2;
            rdo_raw.TabStop = true;
            rdo_raw.Text = "그냥먹기";
            rdo_raw.UseVisualStyleBackColor = true;
            // 
            // rdo_pick
            // 
            rdo_pick.AutoSize = true;
            rdo_pick.Location = new Point(41, 58);
            rdo_pick.Name = "rdo_pick";
            rdo_pick.Size = new Size(49, 19);
            rdo_pick.TabIndex = 1;
            rdo_pick.TabStop = true;
            rdo_pick.Text = "찍먹";
            rdo_pick.UseVisualStyleBackColor = true;
            // 
            // rdo_pour
            // 
            rdo_pour.AutoSize = true;
            rdo_pour.Location = new Point(41, 33);
            rdo_pour.Name = "rdo_pour";
            rdo_pour.Size = new Size(49, 19);
            rdo_pour.TabIndex = 0;
            rdo_pour.TabStop = true;
            rdo_pour.Text = "부먹";
            rdo_pour.UseVisualStyleBackColor = true;
            // 
            // rich_result
            // 
            rich_result.Location = new Point(201, 413);
            rich_result.Name = "rich_result";
            rich_result.Size = new Size(358, 96);
            rich_result.TabIndex = 3;
            rich_result.Text = "#좋아하는 자동차와 탕수육 먹는 방법 #";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 613);
            Controls.Add(rich_result);
            Controls.Add(gbox_tang);
            Controls.Add(gbox_car);
            Controls.Add(btn_run);
            Name = "Form1";
            Text = "Form1";
            gbox_car.ResumeLayout(false);
            gbox_car.PerformLayout();
            gbox_tang.ResumeLayout(false);
            gbox_tang.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btn_run;
        private GroupBox gbox_car;
        private CheckBox cb_porsche;
        private CheckBox cb_audi;
        private CheckBox cb_bmw;
        private CheckBox cb_benz;
        private GroupBox gbox_tang;
        private RadioButton rdo_raw;
        private RadioButton rdo_pick;
        private RadioButton rdo_pour;
        private RichTextBox rich_result;
    }
}
