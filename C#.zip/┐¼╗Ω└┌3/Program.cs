﻿namespace 연산자3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int money;
            int c500, c100, c50, c10;

            Console.WriteLine("교환할 돈은 얼마인가?");

            money = int.Parse(Console.ReadLine());//C의 scanf와 동일

            c500 = money / 500;
            money %= 500;

            c100 = money / 100;
            money %= 100;

            c50 = money / 50;
            money %= 50;

            c10 = money / 10;
            money %= 10;

            Console.WriteLine("\n 500원 짜리 ==>" + c500 + "개");
            Console.WriteLine("\n 100원 짜리 ==>" + c100 + "개");
            Console.WriteLine("\n 50원 짜리 ==>" + c50 + "개");
            Console.WriteLine("\n 10원 짜리 ==>" + c10 + "개");
            Console.WriteLine("\n 바꾸지 못한 잔돈 ==>" + money + "원");




            //int a = 2, b = 3, c = 4;
            //int result1, mok, namugi;
            //float result2;

            //result1 = a + b + -c;
            //Console.WriteLine("{0:D}+{1:D}-{2:D}={3:D}", a,b,c,result1); // C의 %d와 동일하다

            //result1 = a + b * c;
            //Console.WriteLine("{0:D}+{1:D}*{2:D}={3:D}", a, b, c, result1);

            //result2 = a * b / (float)c;
            //Console.WriteLine("{0:D}*{1:D}/{2:D}={3:F}", a, b, c, result2);

            //mok = c / b;
            //Console.WriteLine("{0:d}/{1:D}의 몫은{2:D}", c,b,mok );

            //namugi = c % b;
            //Console.WriteLine("{0:d}%{1:d}의 나머지는{2:d}",c,b,namugi);

        }
    }
}
