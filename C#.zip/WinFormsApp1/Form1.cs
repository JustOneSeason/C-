namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HI");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.BackColor = Color.Blue;
            button2.ForeColor = Color.Red;
            button1.BackColor = Color.Green;
            button1.ForeColor = Color.Orange;
            this.BackColor = Color.Azure; 

        }
    }
}
