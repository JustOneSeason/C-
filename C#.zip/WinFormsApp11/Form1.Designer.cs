﻿namespace WinFormsApp11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_login = new Button();
            tb_id = new TextBox();
            tb_pass = new TextBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btn_login
            // 
            btn_login.BackColor = SystemColors.ActiveCaption;
            btn_login.Location = new Point(385, 161);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(101, 53);
            btn_login.TabIndex = 0;
            btn_login.Text = "로그인";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // tb_id
            // 
            tb_id.Location = new Point(279, 161);
            tb_id.Name = "tb_id";
            tb_id.Size = new Size(100, 23);
            tb_id.TabIndex = 1;
            tb_id.TextChanged += tb_id_TextChanged;
            // 
            // tb_pass
            // 
            tb_pass.Location = new Point(279, 191);
            tb_pass.Name = "tb_pass";
            tb_pass.Size = new Size(100, 23);
            tb_pass.TabIndex = 2;
            tb_pass.TextChanged += tb_pass_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(234, 169);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 3;
            label1.Text = "아이디";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(218, 194);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 4;
            label2.Text = "비밀번호";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tb_pass);
            Controls.Add(tb_id);
            Controls.Add(btn_login);
            Name = "Form1";
            Text = "로그인 창";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_login;
        private TextBox tb_id;
        private TextBox tb_pass;
        private Label label1;
        private Label label2;
    }
}
