namespace 랜덤사진
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random ran = new Random();

            String[] strings = { "dog2.png", "dog1.png" };
            int rndValue = ran.Next(0, strings.Length);

            string a = "D:/images/";

            pictureBox1.Image = Bitmap.FromFile(a + strings[rndValue]);






            //switch (rndValue) {
            //    case 1:
            //        pictureBox1.Image = Bitmap.FromFile("D:/images/dog2.png");
            //        break;
            //    case 2:
            //        pictureBox1.Image = Bitmap.FromFile("D:/images/dog1.png");
            //        break;
            //    case 3:
            //        pictureBox1.Image = Bitmap.FromFile("D:/images/cat2.png");
            //        break;
            //    case 4:
            //        pictureBox1.Image = Bitmap.FromFile("D:/images/cat1.png");
            //        break;

            //}
            //if (rndValue == 2)
            //{
            //    pictureBox1.Image = Bitmap.FromFile("D:/images/dog2.png");
            //}
            //else if (rndValue == 3)
            //{
            //    pictureBox1.Image = Bitmap.FromFile("D:/images/dog1.png");
            //}
            //else {
            //    pictureBox1.Image = Bitmap.FromFile("D:/images/cat2.png");
            //}

        }
    }
}
