namespace WinFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int num = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            int a = button1.Location.X;
            int b = button1.Location.Y;
            Random rnd = new Random();

            int rndX = rnd.Next(0 ,200);
            int rndY = rnd.Next(0 ,400);
            button1.Location = new Point(rndX , rndY);

            label1.Text = (num+=1).ToString();
        }
    }
}
